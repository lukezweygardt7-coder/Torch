package com.truelight.mixin;

import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets us ask the renderer to re-mesh a chunk section (section coordinates). */
@Mixin(WorldRenderer.class)
public interface WorldRendererInvoker
{
    @Invoker("scheduleChunkRender")
    void truelight$scheduleChunkRender(int x, int y, int z, boolean important);
}
