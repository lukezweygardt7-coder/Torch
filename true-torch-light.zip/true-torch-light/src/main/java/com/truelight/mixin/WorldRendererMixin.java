package com.truelight.mixin;

import com.truelight.DynamicLights;
import com.truelight.TrueLightConfig;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Vanilla asks this method for the packed light of every block face it meshes (terrain, block
 * entities, AO). We raise the block-light part to our dynamic light when that is brighter.
 */
@Mixin(WorldRenderer.class)
public class WorldRendererMixin
{
    @Inject(
        method = "getLightmapCoordinates(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;)I",
        at = @At("RETURN"),
        cancellable = true
    )
    private static void truelight$dynamicLight(BlockRenderView world, BlockState state, BlockPos pos, CallbackInfoReturnable<Integer> cir)
    {
        if (!TrueLightConfig.get().enabled)
        {
            return;
        }

        int dynamic = DynamicLights.lightAt(pos);

        if (dynamic <= 0)
        {
            return;
        }

        int packed = cir.getReturnValueI();
        int block = LightmapTextureManager.getBlockLightCoordinates(packed);

        if (dynamic > block && !world.getBlockState(pos).isOpaqueFullCube(world, pos))
        {
            cir.setReturnValue(LightmapTextureManager.pack(dynamic, LightmapTextureManager.getSkyLightCoordinates(packed)));
        }
    }
}
