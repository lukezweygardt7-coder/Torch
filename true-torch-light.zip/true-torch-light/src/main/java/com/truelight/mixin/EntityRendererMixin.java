package com.truelight.mixin;

import com.truelight.DynamicLights;
import com.truelight.TrueLightConfig;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Makes entities, dropped items, and the first-person hand light up near a source too. */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin
{
    @Inject(
        method = "getBlockLight(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/BlockPos;)I",
        at = @At("RETURN"),
        cancellable = true
    )
    private void truelight$entityLight(Entity entity, BlockPos pos, CallbackInfoReturnable<Integer> cir)
    {
        if (!TrueLightConfig.get().enabled)
        {
            return;
        }

        int dynamic = DynamicLights.lightAt(pos);

        if (dynamic > cir.getReturnValueI())
        {
            cir.setReturnValue(dynamic);
        }
    }
}
