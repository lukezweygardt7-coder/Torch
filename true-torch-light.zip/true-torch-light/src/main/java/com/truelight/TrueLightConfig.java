package com.truelight;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Edit config/truelight.json, then restart the game. */
public class TrueLightConfig
{
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static TrueLightConfig instance = new TrueLightConfig();

    /** Master switch. */
    public boolean enabled = true;
    /** How far the light reaches, in blocks. It fades smoothly from the source to this distance. */
    public double radius = 7.0;
    /** Brightness (0-15) right next to the source, per held item. */
    public Map<String, Integer> lightLevels = new LinkedHashMap<>();
    /** Items that flicker like a flame. Lanterns stay steady. */
    public List<String> flickerItems = List.of("minecraft:torch", "minecraft:soul_torch", "minecraft:redstone_torch");
    /** How many brightness levels the flame dips by. 0 turns flicker off. */
    public int flickerDepth = 1;
    /** Ticks between flicker changes (20 ticks = 1 second). Higher = fewer chunk updates. */
    public int flickerInterval = 4;

    public transient Map<Item, Integer> levels = new HashMap<>();
    public transient Set<Item> flickers = new HashSet<>();

    public TrueLightConfig()
    {
        lightLevels.put("minecraft:torch", 14);
        lightLevels.put("minecraft:soul_torch", 11);
        lightLevels.put("minecraft:lantern", 15);
        lightLevels.put("minecraft:soul_lantern", 12);
        lightLevels.put("minecraft:redstone_torch", 8);
    }

    public static TrueLightConfig get()
    {
        return instance;
    }

    public static void load()
    {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("truelight.json");

        try
        {
            if (Files.exists(path))
            {
                try (Reader reader = Files.newBufferedReader(path))
                {
                    TrueLightConfig loaded = GSON.fromJson(reader, TrueLightConfig.class);

                    if (loaded != null && loaded.lightLevels != null)
                    {
                        instance = loaded;
                    }
                }
            }

            try (Writer writer = Files.newBufferedWriter(path))
            {
                GSON.toJson(instance, writer);
            }
        }
        catch (Exception e)
        {
            TrueLightMod.LOGGER.warn("Could not read/write truelight.json, using defaults", e);
        }

        instance.resolve();
    }

    private void resolve()
    {
        levels = new HashMap<>();
        flickers = new HashSet<>();

        for (Map.Entry<String, Integer> e : lightLevels.entrySet())
        {
            Identifier id = Identifier.tryParse(e.getKey());

            if (id != null && Registries.ITEM.containsId(id))
            {
                levels.put(Registries.ITEM.get(id), Math.max(0, Math.min(15, e.getValue())));
            }
            else
            {
                TrueLightMod.LOGGER.warn("Unknown item in truelight.json: {}", e.getKey());
            }
        }

        if (flickerItems != null)
        {
            for (String s : flickerItems)
            {
                Identifier id = Identifier.tryParse(s);

                if (id != null && Registries.ITEM.containsId(id))
                {
                    flickers.add(Registries.ITEM.get(id));
                }
            }
        }
    }
}
