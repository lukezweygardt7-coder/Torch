package com.truelight;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrueLightMod implements ClientModInitializer
{
    public static final Logger LOGGER = LoggerFactory.getLogger("truelight");

    @Override
    public void onInitializeClient()
    {
        TrueLightConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(DynamicLights::tick);
    }
}
