package com.truelight;

import com.truelight.mixin.WorldRendererInvoker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Keeps a list of moving light sources (players holding torches/lanterns) and answers
 * "how bright is the dynamic light at this block?" for the lighting mixins.
 *
 * Nothing is placed in the world: the renderer is simply told the area is brighter.
 * Sources are snapped to block centers so the baked chunk lighting always matches what we
 * scheduled for re-render.
 */
public final class DynamicLights
{
    /** Immutable, so render/mesh threads can read it safely. */
    public record Source(int x, int y, int z, int level)
    {
    }

    private static final Source[] NONE = new Source[0];
    private static volatile Source[] sources = NONE;

    private static final Map<UUID, int[]> FLICKER = new HashMap<>();
    private static final Random RANDOM = new Random();

    private DynamicLights()
    {}

    /** Dynamic block light (0-15) at a block position. Cheap; called from mesh and render threads. */
    public static int lightAt(BlockPos pos)
    {
        Source[] list = sources;

        if (list.length == 0)
        {
            return 0;
        }

        double radius = TrueLightConfig.get().radius;
        double radiusSq = radius * radius;
        int best = 0;

        for (Source s : list)
        {
            double dx = pos.getX() - s.x();
            double dy = pos.getY() - s.y();
            double dz = pos.getZ() - s.z();
            double distSq = dx * dx + dy * dy + dz * dz;

            if (distSq >= radiusSq)
            {
                continue;
            }

            int value = (int) Math.round(s.level() * (1.0 - Math.sqrt(distSq) / radius));

            if (value > best)
            {
                best = value;
            }
        }

        return best;
    }

    public static void tick(MinecraftClient mc)
    {
        TrueLightConfig config = TrueLightConfig.get();
        Source[] old = sources;

        if (!config.enabled || mc.world == null || mc.player == null)
        {
            if (old.length > 0)
            {
                sources = NONE;
                FLICKER.clear();
                rebuild(mc, old, NONE);
            }

            return;
        }

        List<Source> next = new ArrayList<>();
        Set<UUID> active = new HashSet<>();

        for (AbstractClientPlayerEntity player : mc.world.getPlayers())
        {
            if (player.isSpectator() || player.isInvisible() && player != mc.player)
            {
                continue;
            }

            Item item = heldLightItem(player, config);

            if (item == null)
            {
                continue;
            }

            int level = config.levels.get(item);

            if (config.flickerDepth > 0 && config.flickers.contains(item))
            {
                int[] state = FLICKER.computeIfAbsent(player.getUuid(), k -> new int[2]);

                if (--state[1] <= 0)
                {
                    state[1] = Math.max(1, config.flickerInterval);
                    state[0] = RANDOM.nextFloat() < 0.45F ? RANDOM.nextInt(config.flickerDepth + 1) : 0;
                }

                level -= state[0];
            }

            active.add(player.getUuid());

            /* Roughly torch/chest height. */
            BlockPos pos = BlockPos.ofFloored(player.getX(), player.getY() + player.getHeight() * 0.7, player.getZ());

            next.add(new Source(pos.getX(), pos.getY(), pos.getZ(), Math.max(1, Math.min(15, level))));
        }

        FLICKER.keySet().retainAll(active);

        Source[] updated = next.isEmpty() ? NONE : next.toArray(new Source[0]);

        sources = updated;
        rebuild(mc, old, updated);
    }

    private static Item heldLightItem(AbstractClientPlayerEntity player, TrueLightConfig config)
    {
        Item best = null;
        int bestLevel = 0;

        for (ItemStack stack : new ItemStack[] {player.getMainHandStack(), player.getOffHandStack()})
        {
            if (stack.isEmpty())
            {
                continue;
            }

            Integer level = config.levels.get(stack.getItem());

            if (level != null && level > bestLevel)
            {
                best = stack.getItem();
                bestLevel = level;
            }
        }

        return best;
    }

    /** Re-mesh the chunk sections around every source that appeared, moved, changed, or went away. */
    private static void rebuild(MinecraftClient mc, Source[] old, Source[] updated)
    {
        if (mc.worldRenderer == null)
        {
            return;
        }

        Set<Source> oldSet = new HashSet<>(List.of(old));
        Set<Source> newSet = new HashSet<>(List.of(updated));
        Set<Long> sections = new HashSet<>();

        for (Source s : old)
        {
            if (!newSet.contains(s))
            {
                collect(s, sections);
            }
        }

        for (Source s : updated)
        {
            if (!oldSet.contains(s))
            {
                collect(s, sections);
            }
        }

        WorldRendererInvoker invoker = (WorldRendererInvoker) mc.worldRenderer;

        for (long key : sections)
        {
            int x = net.minecraft.util.math.ChunkSectionPos.unpackX(key);
            int y = net.minecraft.util.math.ChunkSectionPos.unpackY(key);
            int z = net.minecraft.util.math.ChunkSectionPos.unpackZ(key);

            invoker.truelight$scheduleChunkRender(x, y, z, false);
        }
    }

    private static void collect(Source s, Set<Long> out)
    {
        int r = (int) Math.ceil(TrueLightConfig.get().radius) + 1;

        for (int sx = (s.x() - r) >> 4; sx <= (s.x() + r) >> 4; sx++)
        {
            for (int sy = (s.y() - r) >> 4; sy <= (s.y() + r) >> 4; sy++)
            {
                for (int sz = (s.z() - r) >> 4; sz <= (s.z() + r) >> 4; sz++)
                {
                    out.add(net.minecraft.util.math.ChunkSectionPos.asLong(sx, sy, sz));
                }
            }
        }
    }
}
